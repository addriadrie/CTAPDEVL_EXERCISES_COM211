package com.example.instaclone.Messages.Model;

public class Chatlist {

    public String id;

    public Chatlist() {
    }

    public Chatlist(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
